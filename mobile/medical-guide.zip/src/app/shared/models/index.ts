export * from './inmunization.model';
