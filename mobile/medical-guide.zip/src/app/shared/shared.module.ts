import { NgModule } from '@angular/core';


const PIPES = [

];
const COMPONENTS = [

];
const DIRECTIVES = [

];

@NgModule({
  declarations: [...COMPONENTS, ...DIRECTIVES, ...PIPES],
  exports: [...COMPONENTS, ...DIRECTIVES, ...PIPES]
})
export class SharedModule { }